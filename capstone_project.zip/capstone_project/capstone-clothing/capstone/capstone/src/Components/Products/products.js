import "./products.css";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// functional component
const Products = () => {   
    const [data, setData] = useState("");

    useEffect(() => {
        fetch("http://localhost:5001/data")
            .then((res) => res.json())
            .then((data) => setData(data));
    }, []);



    // class Products extends React.Component {    // class components in react js


    //     // Constructor 
    //     constructor(props) {
    //         super(props);

    //         this.state = {
    //             items: [],
    //             DataisLoaded: false
    //         };
    //     }

    //     // ComponentDidMount is used to
    //     // execute the code 
    //     componentWillMount() {
    //         fetch(
    //             "http://localhost:5001/data")
    //             .then((res) => res.json())
    //             .then((json) => {
    //                 this.setState({
    //                     items: json,
    //                     DataisLoaded: true
    //                 });
    //             })
    //     }


    // render() {

    return (
        <div>

            <div className="container">
                <div className="row">
                    {data &&
                        data.map((value) => {
                           return <div className="col-3">
                                <Link to={`/productInfo/${value.id}`}>
                                    <img src={`/assets/${value.image}`}
                                    />
                                    <div className="brandName" key={value + "something"}>{value.brand}</div>
                                    <div className="itemName">{value.name}</div>
                                    <div className="price">Rs.{value.discountPrice}
                                        <strike className="strike">Rs.{value.price}</strike>
                                        <span className="discount">{value.discount}</span></div>
                                </Link>
                            </div>
                        })
                    }
                </div>
            </div>
        </div>
    );
    // };
}

export default Products;