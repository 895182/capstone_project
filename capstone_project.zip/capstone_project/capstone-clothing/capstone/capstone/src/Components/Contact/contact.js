import React, { useState } from "react";
import "./contact.scss";
import Header from "../header/Header";



const Contact = () => {

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [number, setNumber] = useState("");
  const [message, setMessage] = useState("");

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let res = await fetch("http://localhost:5001/getInTouchData", {
        method: "POST",
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name: name,
          email: email,
          number: number,
          message: message
        }),
      });
      let resJson = await res.json();
      if (res.status === 200) {
        setName("");
        setEmail("");
        setMessage("User created successfully");
      } else {
        setMessage("Some error occured");
      }
    } catch (err) {
      console.log(err);
    }
  };



  return (
    <div className="App">
      <div>
        <Header
          headerData={{
            backgroundImage: "assets/contact.jpg",
            title: "Contact Us",
            desc: "GOT A QUESTION? WE'LL GIVE YOU STRAIGHT ANSWER",
          }}
        />
      </div>
      <div>
        <section>
          <div className="contact-details">
            <div className="address">
              <p className="text">ADDRESS :</p>
              <p>280 ParK Avenue Z,Cross cut Complex, Bangalore, India</p>
            </div>
            <div className="phone">
              <p className="text">PHONE :</p>
              <p>(91) 987 654 3210</p>
              <p>(91) 987 654 3211
              </p>
            </div>
            <div className="email">
              <p className="text">EMAIL :</p>
              <p>contact@sparkclothing.com</p>
            </div>
          </div>
        </section>
      </div>

      {/* FORM */}
      <div className="contact_form">
        <div className="container">
          <div className="row">
            <div className="col-5">
              <div className="contact_form_container py-5">
                <div className="contact_form_title">
                  Get in Touch</div>
                <form id="contact_form" onSubmit={handleSubmit}>
                  <div className="form-group">
                    <input type="text" value={name} id="contact_name" className="contact_name input_field form-control"
                      placeholder="Your name" onChange={(e) => setName(e.target.value)} required="true" />
                  </div>
                  <div className="form-group">
                    <input type="email" value={email} id="contact_email" className="contact_email input_field form-control"
                      placeholder="Your email" onChange={(e) => setEmail(e.target.value)} required="true" />
                  </div>
                  <div className="form-group">
                    <input type="number" value={number} id="contact_phone" className="contact_phone input_field form-control"
                      placeholder="Your Phone Number"  onChange={(e) => setNumber(e.target.value)} required="true" />
                  </div>
                  <div className="contact_text mt-3">
                    <textarea className="text_field form-control contact_form_message"
                      placeholder="Message" rows="3" onChange={(e) => setMessage(e.target.value)}></textarea>
                  </div>
                  <div className="contact_button">
                    <button type="submit" className="button contact_submit_button">Submit</button>
                  </div>

                </form>
              </div>
            </div>
            <div className="col-7">
              <img src="../assets/images/contact-1.jpg" />
            </div>
          </div>
        </div>
      </div>
    </div>

  );
};

export default Contact;