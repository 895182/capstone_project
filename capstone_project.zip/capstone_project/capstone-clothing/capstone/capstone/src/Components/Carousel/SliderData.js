export const SliderData = [
    {
        image: '../assets/Product1.png'
    },
    {
        image: '../assets/Product2.png'
    },
    {
        image: '../assets/Product3.png'
    },
    {
        image: '../assets/Product4.png'
    },
];